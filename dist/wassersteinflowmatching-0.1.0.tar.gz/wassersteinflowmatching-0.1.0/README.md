WassersteinWormhole
======================

Flow Matching on point clouds with Wasserstein