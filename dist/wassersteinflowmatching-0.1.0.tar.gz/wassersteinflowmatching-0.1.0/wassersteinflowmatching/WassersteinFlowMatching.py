from functools import partial

import jax # type: ignore
import jax.numpy as jnp # type: ignore
import numpy as np 
import optax # type: ignore
from jax import jit, random# type: ignore
from tqdm import trange, tqdm
from flax.training import train_state

import WassersteinFlowMatching.utils_OT as utils_OT # type: ignore
import WassersteinFlowMatching.utils_Noise as utils_Noise # type: ignore
from WassersteinFlowMatching._utils_Transformer import AttentionNN # type: ignore
from WassersteinFlowMatching.DefaultConfig import DefaultConfig # type: ignore


def pad_pointclouds(point_clouds, weights, max_shape=-1):
    """
    :meta private:
    """

    if max_shape == -1:
        max_shape = np.max([pc.shape[0] for pc in point_clouds]) + 1
    else:
        max_shape = max_shape + 1


    weights_pad = np.asarray(
        [
            np.concatenate((weight, np.zeros(max_shape - pc.shape[0])), axis=0)
            for pc, weight in zip(point_clouds, weights)
        ]
    )
    point_clouds_pad = np.asarray(
        [
            np.concatenate(
                [pc, np.zeros([max_shape - pc.shape[0], pc.shape[-1]])], axis=0
            )
            for pc in point_clouds
        ]
    )

    weights_pad = weights_pad / weights_pad.sum(axis=1, keepdims=True)

    return (
        point_clouds_pad[:, :-1].astype("float32"),
        weights_pad[:, :-1].astype("float32"),
    )



class WassersteinFlowMatching:
    """
    Initializes Wormhole model and processes input point clouds


    :param point_clouds: (list of np.array) list of train-set point clouds to flow match
    :param config: (flax struct.dataclass) object with parameters

    :return: initialized WassersteinFlowMatching model
    """

    def __init__(
        self,
        point_clouds,
        noise_type = 'uniform',
        config=DefaultConfig,
    ):

        self.config = config
        self.point_clouds = point_clouds


        self.weights = [
            np.ones(pc.shape[0]) / pc.shape[0] for pc in self.point_clouds
        ]


        self.point_clouds, self.weights = pad_pointclouds(
            self.point_clouds, self.weights
        )

        self.space_dim = self.point_clouds.shape[-1]


        self.transport_plan_jit = jax.jit(
            jax.vmap(utils_OT.transport_plan, (0, 0, None, None), 0),
            static_argnums=[2, 3],
        )


        self.scale = config.scale
        self.factor = config.factor
        self.point_clouds = self.scale_func(self.point_clouds) * self.factor
        self.max_val, self.min_val = self.point_clouds.max(), self.point_clouds.min()

        self.noise_type = noise_type
        self.noise_func = getattr(utils_Noise, self.noise_type)


    def scale_func(self, point_clouds):
        """
        :meta private:
        """

        if self.scale == "min_max_total":
            if not hasattr(self, "max_val"):
                self.max_val_scale = self.point_clouds.max(keepdims=True)
                self.min_val_scale = self.point_clouds.min(keepdims=True)
            else:
                print("Using Calculated Min Max Scaling Values")
            return 2 * (point_clouds - self.max_val_scale) / (self.max_val - self.min_val_scale) - 1
        return point_clouds


    def create_train_state(self, model, learning_rate, decay_steps = 10000, key = random.key(0)):
        """
        :meta private:
        """

        subkey, key = random.split(key)
        attn_inputs =  self.noise_func(size = [10, self.point_clouds[0].shape[0], self.space_dim], 
                                       minval = self.min_val, 
                                       maxval = self.max_val, key = subkey)
        
        subkey, key = random.split(key)

        params = model.init(rngs={"params": subkey}, 
                            point_cloud = attn_inputs, 
                            t = jnp.ones((attn_inputs.shape[0])), 
                            masks = jnp.ones((attn_inputs.shape[0], attn_inputs.shape[1])), 
                            deterministic = True)['params']

        lr_sched = optax.exponential_decay(
            learning_rate, decay_steps, 0.6, staircase = True,
        )
        tx = optax.adam(lr_sched)  #

        return train_state.TrainState.create(apply_fn=model.apply, params=params, tx=tx)

    @partial(jit, static_argnums=(0,))
    def train_step(self, state, point_clouds_batch, weights_batch, key=random.key(0)):
        """
        :meta private:
        """
        subkey_t, subkey_noise, key = random.split(key, 3)
        
        noise_samples =  self.noise_func(size = point_clouds_batch.shape, 
                                minval = self.min_val, 
                                maxval = self.max_val, key = subkey_noise)
        noise_weights = weights_batch

        interpolates_time = random.uniform(subkey_t, (point_clouds_batch.shape[0],), minval=0.0, maxval=1.0)
        
        optimal_flow = jnp.nan_to_num(self.transport_plan_jit([noise_samples, noise_weights], 
                                                              [point_clouds_batch, weights_batch]), neginf=0)
        point_cloud_interpolates = noise_samples + (1-interpolates_time[:, None, None]) * optimal_flow

        
        subkey, key = random.split(key)

        def loss_fn(params):        
            predicted_flow = state.apply_fn({"params": params},  
                                                point_cloud = point_cloud_interpolates, 
                                                t = interpolates_time, 
                                                masks = noise_weights>0, 
                                                deterministic = False, 
                                                dropout_rng = subkey)
            error = jnp.square(predicted_flow - optimal_flow) * noise_weights[:, :, None]
            loss = jnp.mean(jnp.sum(error, axis = 1))
            return loss
        
        loss, grads = jax.value_and_grad(loss_fn)(state.params)
        state = state.apply_gradients(grads=grads)
        return (state, loss)

    def train(
        self,
        training_steps=10000,
        batch_size=16,
        verbose=8,
        init_lr=0.0001,
        decay_num=4,
        key=random.key(0),
    ):
        """
        Set up optimization parameters and train the ENVI moodel


        :param training_steps: (int) number of gradient descent steps to train ENVI (default 10000)
        :param batch_size: (int) size of train-set point clouds sampled for each training step  (default 16)
        :param verbose: (int) amount of steps between each loss print statement (default 8)
        :param init_lr: (float) initial learning rate for ADAM optimizer with exponential decay (default 1e-4)
        :param decay_num: (int) number of times of learning rate decay during training (default 4)
        :param key: (jax.random.key) random seed (default jax.random.key(0))

        :return: nothing
        """



        batch_size = min(self.point_clouds.shape[0], batch_size)

        subkey, key = random.split(key)

        self.FlowMatchingModel = AttentionNN()
        self.state = self.create_train_state(self.FlowMatchingModel, 
                                             learning_rate=init_lr, 
                                             decay_steps = int(training_steps / decay_num), 
                                             key = subkey)


        tq = trange(training_steps, leave=True, desc="")
        losses = []
        for training_step in tq:

            subkey, key = random.split(key, 2)
            batch_ind = random.choice(
                key=subkey,
                a = self.point_clouds.shape[0],
                shape=[batch_size],
                replace=False)
            

            point_clouds_batch, weights_batch = self.point_clouds[batch_ind],  self.weights[batch_ind]

            subkey, key = random.split(key, 2)
            self.state, loss = self.train_step(self.state, point_clouds_batch, weights_batch, key = subkey)
            losses.append(loss) 

            if(training_step % verbose == 0):
                tq.set_description(": {:.3e}".format(loss))

    @partial(jit, static_argnums=(0,))
    def get_flow(self, point_clouds, t):

        if(point_clouds.ndim == 2):
            point_clouds = point_clouds[None,:, :]

        flow = jnp.squeeze(self.FlowMatchingModel.apply({"params": self.state.params},
                    point_cloud = point_clouds, 
                    t = t * jnp.ones(point_clouds.shape[0]), 
                    masks = jnp.ones((point_clouds.shape[0], point_clouds.shape[1])), 
                    deterministic = True))
        return(flow)
    
    def generate_samples(self, num_samples = 10, timesteps = 100, key = random.key(0)): 
        """
        Generate samples from the learned flow


        :param num_samples: (int) number of samples to generate (default 10)
        :param timesteps: (int) number of timesteps to generate samples (default 100)

        :return: generated samples
        """

        subkey, key = random.split(key)
        noise =  [self.noise_func(size = [num_samples, self.point_clouds.shape[1], self.space_dim], 
                                minval = self.min_val, 
                                maxval = self.max_val, key = subkey)]
        dt = 1/timesteps

        for t in tqdm(jnp.linspace(1, 0, timesteps)):
            grad_fn = self.get_flow(noise[-1], t)*dt
            noise.append(noise[-1] + dt * grad_fn)
        return noise